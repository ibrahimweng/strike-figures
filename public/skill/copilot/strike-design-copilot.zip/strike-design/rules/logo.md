# Logo

The Strike mark is three 3D chevrons stacked into one form. The layers stand for structure and continuity. One mark, built two ways:
- **3D, for screens:** the app, the website, social posts and slides. Gray side faces give it depth.
- **Flat, for anything printed or made:** merch, stickers, embroidery, packaging. One solid color, no gray.

## Which file
| Ground | Use | File (strike-design/assets/logo/) |
|---|---|---|
| Dark (ground #0C0C0C, product UI) | 3D green mark, white STRIKE | strike-lockup-3d-green.svg · strike-mark-3d-green.svg |
| Light (white, light gray) and mint, on screen | 3D black, gray side faces | strike-lockup-3d-black.svg · strike-mark-3d-black.svg |
| Mint, bright or light grounds in print and merch; on screen under 32 px | Flat black | strike-lockup-flat-black.svg · strike-mark-flat-black.svg |
| Photo, soft | 3D white | strike-lockup-3d-white.svg · strike-mark-3d-white.svg |
| Photo, busy or noisy; green posters; print and merch on dark | Flat white | strike-lockup-flat-white.svg · strike-mark-flat-white.svg |
| Avatars, app icons | Mark on its tile | strike-mark-tile.svg |
| Round avatars, favicons | Mark on a disc | strike-mark-disc.svg |
| Link previews | 1200 × 630 | strike-og.png |

- The 3D green mark also works on light gray grounds, as in the brand book (1.12).
- The wordmark alone (strike-wordmark-black/white.svg) is for places where the mark already appears nearby.
- Use the lockup where there's room for the name, the mark alone where there isn't.

## Size
| | Minimum | |
|---|---|---|
| 3D, on screen | 32 px wide | Under 32 px, use the flat mark |
| Flat, on screen | 16 px | |
| Flat, print | 8 mm | |
| Flat, screen print | 12 mm | |
| Flat, embroidery | 35 mm | |
| Lockup | 20 px tall | |

- **Maximum:** never wider than one third of the layout. It scales with the layout.

## Clear space
Keep the width of the S in STRIKE (about 0.37 of the mark's height) clear on every side of the mark and of the lockup. Measure the S at the size the logo is used.

## Rules
- Never on a flat Strike Green ground in UI. On posters and brand art, the logo may sit on mint (3D black on screen, flat black in print).
- Never recolor, outline, add shadows, glows or other effects, stretch, rotate, separate the layers, or redraw it.
- Text: write "Strike". STRIKE in capitals, tracked 0.22 em in Ciburial, exists only inside the logo files.
- Place it in a corner of the layout grid, not centered over content, unless the logo is the subject (a cover, a sign-off). One logo per layout.

## Sub-brands (only when asked)
Strike has no official sub-brands. Build a lockup only when asked, the way the brand book does (1.9, 1.10). M is the height of the mark:
- **Horizontal:**
  - the mark;
  - a 0.43 M gap;
  - STRIKE (cap height 0.47 M, centered on the mark);
  - a 0.47 M gap;
  - the name in Geist Medium, sentence case, 1.22× STRIKE's height, on STRIKE's baseline.
- **Stacked:** the small lockup on top. Below it, 0.27 M lower, the name in Geist Medium at 1.31 M, left-aligned.
- **Powered by:** "Powered by" in Geist Medium at 0.6× STRIKE's cap height, centered on the mark, 0.6 M before it.

With the repo's scripts available, generate it: `node strike-design/scripts/lockup.mjs --name "Markets" --layout horizontal --version 3d-green`. Otherwise compose it from the logo files with these proportions.
