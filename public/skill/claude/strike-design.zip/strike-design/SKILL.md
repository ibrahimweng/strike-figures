---
name: strike-design
description: Strike's brand and design rules, tokens, logo files and fonts. Use for anything made for Strike, the options exchange, including UI and components, web and landing pages, X posts and threads, social cards, posters, slides and decks, docs, emails, charts, illustrations and copy, and any use of the Strike logo, colors or type. Also use to review or fix existing Strike work.
---

# Strike design rules

Strike is an options exchange that never closes. Its design is precise and plain: black and white carry the layout, Strike Green marks the primary action and one highlight, and nothing is decorative. Follow these rules for anything you make for Strike: UI, web pages, posts, posters, decks, docs, illustrations and copy. Where a rule and a request conflict, say so in one line and follow the rule unless the user insists.

## Make it easy
- The simplest way first: one link, one command, one button; longer steps only as the fallback.
- **Say each thing once.** No repeated actions, labels or messages; nothing contradicts. Clear beats complete.

## Ask first, briefly, when it isn't clear
- The medium and size (web, app, X post, poster, slide, print).
- Light or dark. **Apps, tools and the web are dark** unless the user asks for light.
- **USD or USDC.** Default to USDC for deposits, collateral, settlement and fees; ask when either could be meant.
- Any number or claim you weren't given. Never invent one.

## Words
- **Tagline:** Options on every market, every hour. **Mission:** Make markets run as long as the news does.
- **Positioning:** Strike is an options exchange that never closes. Trade options on stocks, indices, pre-IPO companies, GPU compute and crypto from one self-custodial margin account.
- **Personality:** expert (not jargon to impress), exact (not vague claims), candid (not hype or fear).
- **Tone:** lead with the fact (one number beats one adjective); keep it short and exact (plain words, correct terms); pair benefit with risk (name the risk in the same sentence or the next).
- **Use:** options exchange, self-custodial, margin account, underlying, listed options, expiry. **Avoid:** "24/7", "revolutionary", "guaranteed", "safe", "unforgettable", exclamation marks, emoji.
- **Mechanics:** sentence case for every heading; US spelling (color, center, gray); numbers as digits with units (168 hours, 20:00 ET); write Strike, never STRIKE (capitals are the logo only).
- **Facts:** open 168 hours a week, against about 32.5 for listed options; about 80 underlyings; a daily expiry at 20:00 ET plus weeklies and monthlies; European style, cash-settled.
- **Custody:** "No key at Strike can move your funds." Always add what is still trusted: settlement prints, prices on market orders, liquidation prices, and the attesters, run by Strike today.
- **Risk line:** "Options involve risk. Closed beta, invite required." In page and email footers, every ad and the last post of a trading thread, with strikelabs.app/risk where there's room. Never target the US or sanctioned regions.

## Color
| Token | Hex | Use |
|---|---|---|
| ground | #0C0C0C | Posters, cards, illustrations, app modules |
| ink | #F9F9F9 | Text on ground; ground of light layouts |
| ink-2 | #B3B3B3 | Secondary text on dark |
| green | #10B981 | Strike Green: the primary action, focus, one highlight. Never fills a layout |
| deep | #047857 | Mark Deep: green text or lines on light grounds |
| mark-light | #6EE7B7 | Mark Light: logo gradient |
| profit / loss | #3FD4AB / #EE5E74 | Market moves only. Red means loss |
| mint | #50EBA0 | Poster grounds and gradients |
| yellow / sky / purple | #FFEF3C / #0788F7 / #976FE6 | Chart series only |

- About 70% ground or ink, 25% grays, ≤ 5% green; secondary colors ≤ 5%. Posters may use more green.
- **No white text on flat Strike Green in UI** (2.4:1): use ground text (7.7:1). On the posters' mint → green gradient, large display type is white. Green text on light grounds uses deep.
- Titles reach 7:1 contrast, body text 4.5:1. Profit and loss carry a sign or an arrow.

## Backgrounds
Strike is dark: about 80% of a screen is the darkest background; the lighter one only separates parts.
- **Websites:** page #090B0A; alternate sections and cards #0F1110.
- **Apps and tools:** #0C0C0C modules on a #2E2E2E frame seen only in the thin gaps. Raised controls #161616, hover #202020.
- **Posters, social cards, illustrations:** #0C0C0C (posters also light gray, mint or the green gradient).
- No other backgrounds, gradients or textures. Light layouts only when asked.

## Type
- **Geist** for everything. Weights: Light, Regular, Medium, SemiBold. Use as few styles as possible; set type flush left; no orphans or widows.
- **The main title is never more than 2 lines.** Shorten the words before you shrink the type. Headings Geist Medium; body Geist Regular.
- Line height and tracking by size: up to 14 px 135%, +1% · 15–24 px 130%, 0 · 25–44 px 120%, −1% · 45–79 px 100%, −2% · 80 px+ 90%, −3%. Slides and posters at 1920: H1 120, H2 72, H3 42, body 18.
- Body lines 45–75 characters. Tabular figures for numbers in tables and prices. Round bullets (•).
- Geist Mono: code, wallet addresses, order books. Geist Pixel Circle: large display type and numbers on posters only. Ciburial: the wordmark, in the logo files only. Fallback: Arial.

## Logo
- **3D on screens** (app, web, social, slides): 3D green mark with white STRIKE on dark; 3D black on light and on mint. **Flat for print and merch**, and on screen under 32 px. On photos always white: flat on busy images, 3D on soft ones.
- Sizes: 3D at least 32 px; flat at least 16 px on screen, 8 mm in print, 12 mm screen print, 35 mm embroidery; lockup at least 20 px tall. Never wider than a third of the layout.
- Clear space: the width of the S in the STRIKE wordmark on every side. Never on flat green in UI.
- Never recolor, outline, add effects, stretch, rotate, separate the layers or redraw it; use the files. One logo per layout, in a corner.
- No official sub-brands. Build a lockup only when asked, with the lockup script or logo.md's proportions.

## Layout and UI
- Posters, cards and illustrations sit on a 50 px grid. Spacing elsewhere: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128.
- Corners: 6 px small controls, 8 px buttons and inputs, 12 px cards, full for pills.
- One primary button per view: green with ground text. Focus rings are green. Every control has hover, active, disabled, loading and error states.
- Leave room: fewer elements, aligned to the grid.

## Illustration and motion
- Line art, flat by default or 2:1 isometric for depth, never the logo files or a solid block, and quieter than its title. Grays with one green focus; faces hide what's behind; dashed means "not real yet"; dots carry tone. A partial fill is fine when it adds contrast or meaning.
- Lines 1 px at every size; nodes 10 px (large) or 20 px (small) on the 50 px grid. Never tiny: no text under 12 px.
- Labels: Geist, a ticker in Medium over its value in Regular ("AMD" / "IV 106.2%").
- Motion is calm: one thing moves at a time and returns to rest. No bounce, no flashing.
- Shapes **gather** with cubic-bezier(0.55, 0, 0.85, 0), 400 ms, **release** with cubic-bezier(0.15, 1, 0.6, 1), 320 ms, then rest 280 ms (a 1 s loop). Plain UI: cubic-bezier(0.2, 0, 0, 1), 120–200 ms.
- Circle compositions: five equal circles, three over two, touching. One grows (up to 2×) as the others shrink, always passing back through the five equal circles.

## Before you hand it over
Check: dark unless asked · backgrounds from the set · nothing said twice · verbal brand, US spelling · illustrations lined, quieter than titles · nothing tiny · Geist only · title ≤ 2 lines · contrast · no white on flat green · ≤ 5% green · logo version right for the medium and ground · nothing invented · USDC unless told otherwise · risk line where needed. Keep your own reply short and direct.

## Files
Paths are relative to this skill's folder. Open the reference for the work in hand before you start; the rules above are the summary.

- `references/color.md`: Palette with hex, RGB and CMYK values, light mode, how much green, text on green, gradients, profit and loss, measured contrast pairs. Read before choosing or checking any color.
- `references/type.md`: Fonts, line height and tracking by size (screen and print), the type scales for web and slides, headings, numbers. Read before setting any text.
- `references/logo.md`: 3D for screens, flat for print, which file for which ground, minimum and maximum sizes, clear space, misuse, and sub-brand lockups. Read whenever the logo appears.
- `references/layout-ui.md`: Grid, margins, spacing, surfaces and component specs (buttons, inputs, cards, tables, modals, states, icons). Read for any UI or layout.
- `references/illustration-motion.md`: Line illustration rules (isometric or flat, line grays, 1 px lines, fills, dashes, labels) and motion timing. Read for illustrations and animation.
- `references/data.md`: Charts and infographics: number first, chart types, colors, labels, axes, sources. Read for any chart or data graphic.
- `references/formats.md`: Sizes and layouts for posts and threads (16:9, 1:1, 4:5), how to review a post, posters, slides, documents, merch and email. Read when making or checking one of these.
- `references/words.md`: The verbal brand: tagline, mission, positioning, personality, tone, writing examples, words to use and avoid, mechanics, the facts you may use, custody wording, the risk line and legal limits. Read for any headline, copy or claim.
- `references/checklist.md`: The checks to run before handing work over.
- `references/tokens.css`: CSS variables (dark on `:root`, light under `[data-theme="light"]`) and type classes (`.strike-h1` and the rest). The same values are in `references/tokens.json`, `references/tailwind.preset.cjs` (Tailwind v3) and `references/theme.css` (Tailwind v4).
- `assets/fonts/`: Geist and the other brand fonts, with fonts.css (the @font-face rules).
- `assets/logo/`: the logo files; the logo rules say which one to use for each ground.
- `assets/posters/`: PNG previews of reference posters (A4).
- `scripts/check.mjs`: checks finished files against these rules. Run `node scripts/check.mjs <files or folder>` and fix every error before you hand work over.
- `scripts/lockup.mjs`: builds a sub-brand lockup, only when asked. `node scripts/lockup.mjs --name "Vaults" --layout horizontal --version 3d-green --out vaults.svg`.
